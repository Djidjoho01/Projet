#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h> 
#include <sys/shm.h>  
#include <sys/sem.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>           /* For O_* constants */
#include <sys/stat.h>        /* For mode constants */
#include <semaphore.h>  

int main()
{
    int i=0, j, k, z;
    int tab[3][3], result[3][3];
    int a1, status, a;
    FILE* fichier=NULL;
   	// clé pour la mémoire protégée
    key_t key = ftok("shmfile",65);
    // On demande au system de creer la memoire partagee 
    int shmid = shmget(key,1024,0666|IPC_CREAT); 
    // on attache la memoire partagee a str
    char *str = (char*) shmat(shmid,(void*)0,0); 
    fichier = fopen("coord.txt", "r+");
   if (fichier != NULL)
    {
        while(fscanf(fichier, "%d \n",&a1)!= EOF && i<9)
        {
        	printf("[%d] \n",a1);
           	sprintf(str+i, "%d", a1);      
 			for (k=0; k<3; k++)
    		{
        		for (j=0; j<3; j++)
       	 		{
                	tab[k][j]=a1;
        		}
   		 	}
   		  i++;
        }
        fclose(fichier);
    }
    else
    {
        printf("Impossible d'ouvrir le fichier coord.txt");
        fclose(fichier);
    }
 	
 	 // clé pour la mémoire protégée
    key_t key1 = ftok("shmfile",55);
    // On demande au system de creer la memoire partagee 
     int shmid1 = shmget(key1,1024,0666|IPC_CREAT); 
    // on attache la memoire partagee a str
    char *str1 = (char*) shmat(shmid1,(void*)0,0);
   		pid_t pid1;
   		pid1 = fork();
    	if(pid1 < 0){
        perror("Erreur de création du processus\n");
        exit(EXIT_FAILURE);
    	}
    	if(pid1 == 0){
    		i=0;
    		for (k=0; k<3; k++)
    		{
        		for (j=0; j<3; j++)
        		{
        			result[k][j]=0;
            		for(z=0; z<3; z++)
            		{
                		result[k][j] = tab[k][z] * tab[z][j] + result[k][j];
            		}
            		sprintf(str+i, "%d", result[k][j]);
            		printf("%d\n", result[k][j]);
            		i++;
        		}
    		}
    	}
    	else
    	{
    		pid1 = wait(&status);
            printf("Status de l'arret du fils %d %d\n", status, pid1);
        }
 	 //le processus détache str de la mémoire partagée 
         shmdt(str); 
         shmdt(str1); 
       // destruction de la mémoire 
       shmctl(shmid,IPC_RMID,NULL);
    return 0;
}
